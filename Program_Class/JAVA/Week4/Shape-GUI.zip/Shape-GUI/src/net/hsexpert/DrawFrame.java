package net.hsexpert;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by ikaros on 2015/3/23.
 */
public class DrawFrame extends JFrame implements ActionListener{
    public DrawPanel DrawPanel;
    public JPanel BottomPanel;
    public JPanel ActionPanel;
    public JPanel ShapePanel;
    public JPanel ColorPanel;
    JButton btnClear;
    JButton btnUndo;
    JButton btnRedo;
    JButton btnRandomGenerate;
    JButton btnRect;
    JButton btnTriangle;
    JButton btnOval;

    public DrawFrame() throws HeadlessException {
        DrawPanel = new DrawPanel();
        BottomPanel = new JPanel();
        ActionPanel = new JPanel(new GridLayout(1,4));
        ShapePanel = new JPanel(new GridLayout(1,4));
        btnClear = new JButton("Clear");
        btnUndo = new JButton("Undo");
        btnRedo = new JButton("Redo");
        btnRandomGenerate = new JButton("Random generate");
        btnRect = new JButton("Rect");
        btnOval = new JButton("Oval");
        btnTriangle = new JButton("Triangle");

        ActionPanel.add(btnClear);
        ActionPanel.add(btnUndo);
        ActionPanel.add(btnRedo);
        ActionPanel.add(btnRandomGenerate);

        ShapePanel.add(btnRect);
        ShapePanel.add(btnTriangle);
        ShapePanel.add(btnOval);

        this.add(DrawPanel, BorderLayout.CENTER);
        this.add(BottomPanel, BorderLayout.SOUTH);
        BottomPanel.add(ActionPanel);
        BottomPanel.add(ShapePanel);

        btnRect.addActionListener(this);
        btnTriangle.addActionListener(this);
        btnOval.addActionListener(this);

        btnRandomGenerate.addActionListener(this);
        btnClear.addActionListener(this);
        btnUndo.addActionListener(this);
        btnRedo.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnRandomGenerate){
            DrawPanel.paintTest();
        }
        else if (e.getSource() == btnRect)
        {
            Rect R = Rect.generateRandomRect();
            DrawPanel.ShapeList.add(R);
            DrawPanel.repaint();
        }
        else if (e.getSource() == btnTriangle)
        {
            Triangle T = Triangle.generateRandomTriangle();
            DrawPanel.ShapeList.add(T);
            DrawPanel.repaint();
        }

        else if (e.getSource() == btnOval)
        {
            Oval O = Oval.generateRandomOval();
            DrawPanel.ShapeList.add(O);
            DrawPanel.repaint();
        }
        else if (e.getSource() == btnUndo)
        {
            int  i;
            for(i = DrawPanel.ShapeList.size()-1; i >= 0; i--)
                if (DrawPanel.ShapeList.get(i).getVisible() == true){
                    DrawPanel.ShapeList.get(i).setVisible(false);
                    break;
                }
            DrawPanel.repaint();
        }
        else if (e.getSource() == btnRedo)
        {
            int  i;
            for(i = 0; i < DrawPanel.ShapeList.size(); i++)
                if (DrawPanel.ShapeList.get(i).getVisible() == false){
                    DrawPanel.ShapeList.get(i).setVisible(true);
                    break;
                }
            DrawPanel.repaint();
        }
        else if (e.getSource() == btnClear)
        {
            DrawPanel.ShapeList.clear();
            DrawPanel.repaint();
        }
    }
}
