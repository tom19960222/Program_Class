package net.hsexpert;

/**
 * Created by ikaros on 2015/3/17.
 */
public class ShapeTest {
    public static void main(String[] args)
    {
        DrawFrame app = new DrawFrame();
        app.setSize(1280, 720);
        app.setVisible(true);
    }

}
