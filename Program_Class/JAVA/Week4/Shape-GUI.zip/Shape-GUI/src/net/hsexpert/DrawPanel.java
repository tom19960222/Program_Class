package net.hsexpert;

import javax.swing.*;
import java.awt.*;
import java.util.*;


/**
 * Created by ikaros on 2015/3/17.
 */
public class DrawPanel extends JPanel {

    java.util.List<Shape> ShapeList = new ArrayList<Shape>();

    public void drawAll(Graphics G)
    {
        for (Shape S : ShapeList)
            S.draw(G);
    }
    public void paintTest()
    {
        for(int i = 0; i < 1000; i++)
            ShapeList.add(Rect.generateRandomRect());
        repaint();
    }

    @Override
    public void paintComponent(Graphics G)
    {
        super.paintComponent(G);
        drawAll(G);
    }
}
