package net.hsexpert;

import java.awt.*;
import java.util.Random;

/**
 * Created by ikaros on 2015/3/17.
 */
public class Rect extends Shape {
    public Rect(int x1, int x2, int y1, int y2) {
        super(x1,x2,y1,y2);
    }

    public void draw(Graphics G) {
        if(!this.visible) return;
        G.setColor(this.color);
        if (filled) G.fillRect(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));
        else G.drawRect(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));
    }

    public static Rect generateRandomRect()
    {
        Random rnd = new Random();
        int x1, x2, y1, y2, R, G, B;
        x1 = rnd.nextInt(1000);
        x2 = rnd.nextInt(1000);
        y1 = rnd.nextInt(700);
        y2 = rnd.nextInt(700);
        R = rnd.nextInt(255);
        G = rnd.nextInt(255);
        B = rnd.nextInt(255);

        Rect rect = new Rect(x1,x2,y1,y2);
        rect.setColor(new Color(R, G, B));
        rect.setFilled(rnd.nextBoolean());

        return rect;
    }
}
